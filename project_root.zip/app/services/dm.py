# Placeholder for DMService implementation
class DMService:
    async def send(self, user_id: str, message: str):
        pass
