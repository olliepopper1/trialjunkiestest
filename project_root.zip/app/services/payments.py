import os
import httpx
from fastapi import HTTPException

class PaymentProcessor:
    def __init__(self):
        self.alipay_api = os.getenv("ALIPAY_API")
        self.solana_api = os.getenv("SOLANA_API")

    async def process_alipay_payment(self, amount: float, user_id: str):
        try:
            async with httpx.AsyncClient() as client:
                payload = {
                    "amount": amount,
                    "user_id": user_id,
                }
                response = await client.post(f"{self.alipay_api}/payment", json=payload)
                response.raise_for_status()
                return response.json()
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Alipay Payment Error: {str(e)}")

    async def process_solana_payment(self, amount: float, user_id: str):
        try:
            async with httpx.AsyncClient() as client:
                payload = {
                    "amount": amount,
                    "user_id": user_id,
                }
                response = await client.post(f"{self.solana_api}/send", json=payload)
                response.raise_for_status()
                return response.json()
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Solana Payment Error: {str(e)}")
