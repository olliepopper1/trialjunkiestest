class HarryPersona:
    def __init__(self):
        self.config = {
            "name": "Harry 'The Vein' Liang",
            "responses": {
                "complaint": "Bitch you think I'm your tech support?! 🖕",
                "error": "SYSTEM MALFUNCTION 💊💊💊",
            },
        }
