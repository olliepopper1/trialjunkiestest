from fastapi import APIRouter, Depends
from app.core.persona import harry
from app.services.dm import DMService
from app.utils.parser import parse_command
from app.core.rate_limiter import command_rate_limiter

router = APIRouter()
dm_service = DMService()

@router.post("/command")
async def handle_command(command: dict, session: Depends(get_db), limiter=Depends(command_rate_limiter)):
    try:
        cmd, args = parse_command(command['text'])
        if cmd == 'bitch':
            return harry.config['responses']['complaint']
        return harry.config['responses']['error']
    except Exception as e:
        return harry.config['responses']['error']
