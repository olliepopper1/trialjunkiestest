from fastapi import APIRouter, Request, Depends
from app.services.accounts import AccountGenerator
from app.services.dm import DMService
from app.services.payments import PaymentProcessor
from app.core.persona import harry

router = APIRouter()
account_gen = AccountGenerator()
dm_service = DMService()
payment_processor = PaymentProcessor()

@router.post("/webhook/payment")
async def payment_webhook(request: Request):
    data = await request.json()
    service = data.get('service')
    payment_method = data.get('payment_method')
    amount = data.get('amount')
    user_id = data.get('user_id')

    if payment_method == 'alipay':
        await payment_processor.process_alipay_payment(amount, user_id)
    elif payment_method == 'solana':
        await payment_processor.process_solana_payment(amount, user_id)

    account = await account_gen.generate(service, plan)
    encrypted_creds = harry.fernet.encrypt(
        f"{account.username}:{account.password}".encode()
    )

    await dm_service.send(
        user_id=user_id,
        message=f"🔥 YOUR {service.upper()} FIX
{encrypted_creds.decode()}"
    )
    
    return {"status": "success"}
