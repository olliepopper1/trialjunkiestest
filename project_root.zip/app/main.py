import os
from fastapi import FastAPI, Depends
from app.core.rate_limiter import sliding_window_rate_limiter
from app.routers import commands, payments
from app.db.session import AsyncSessionLocal

app = FastAPI()

# Add routers
app.include_router(commands.router)
app.include_router(payments.router)

@app.middleware("http")
async def concurrency_control(request, call_next):
    response = await call_next(request)
    return response

@app.get("/health")
async def health_check():
    return {"status": "operational"}
